export * from './contactController.service';
import { ContactControllerService } from './contactController.service';
export const APIS = [ContactControllerService];
