package org.ska.business.exceptions;

/**
 * Created by <a href="mailto:pasquale.paola@eng.it">Pasquale Paola</a> on 08/10/18.
 */
public class KissBusinessException extends Exception {

    public KissBusinessException(String msg){
        super(msg);
    }
}
